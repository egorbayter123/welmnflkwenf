from dataclasses import dataclass

from environs import Env


@dataclass
class RedisConfig:
    use_redis: bool
    ip: str


@dataclass
class BotConfig:
    token: str
    fleep_token: str
    admins: list[int]


@dataclass
class Config:
    bot: BotConfig
    redis: RedisConfig


def load_config():
    env = Env()
    env.read_env()

    return Config(
        bot=BotConfig(
            token=env.str("BOT_TOKEN"),
            fleep_token=env.str("FLEEP_TOKEN"),
            admins=env.list("ADMINS", subcast=int)
        ),

        redis=RedisConfig(
            use_redis=env.bool("USE_REDIS"),
            ip=env.str("REDIS_IP")
        )
    )
