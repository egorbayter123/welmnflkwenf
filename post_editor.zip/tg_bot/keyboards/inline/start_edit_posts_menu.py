from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

add_offer_btn = InlineKeyboardButton("Добавить оффер", callback_data="start_edit_posts_menu:add_offer")
start_edit_posts_btn = InlineKeyboardButton("Запустить редактирование постов", callback_data="start_edit_posts_menu:run")
start_edit_posts_keyboard = InlineKeyboardMarkup(row_width=1).add(add_offer_btn, start_edit_posts_btn)
