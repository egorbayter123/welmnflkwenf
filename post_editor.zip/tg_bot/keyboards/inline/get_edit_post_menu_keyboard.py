import logging

from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from tg_bot.keyboards.reply.start_menu import return_start_menu_btn


async def get_edit_post_menu_keyboard(state: FSMContext) -> InlineKeyboardMarkup:
    state_data = await state.get_data()
    keyboard = InlineKeyboardMarkup(row_width=2)

    set_text_btn = InlineKeyboardButton("Установить текст", callback_data="edit_post_menu:set_text")
    edit_text_btn = InlineKeyboardButton("Изменить текст", callback_data="edit_post_menu:set_text")

    set_buttons_btn = InlineKeyboardButton("Добавить кнопки", callback_data="edit_post_menu:set_buttons")
    edit_buttons_btn = InlineKeyboardButton("Изменить кнопки", callback_data="edit_post_menu:set_buttons")

    continue_editing_post = InlineKeyboardButton("Продолжить", callback_data="edit_post_menu:continue")

    if state_data.get("post_text") is None and state_data.get("post_keyboard") is None:
        keyboard.add(set_text_btn, set_buttons_btn)
    elif state_data.get("post_text") is None:
        keyboard.add(edit_text_btn, set_buttons_btn, continue_editing_post)
    elif state_data.get("post_keyboard") is None:
        keyboard.add(edit_text_btn, set_buttons_btn, continue_editing_post)
    else:
        keyboard.add(edit_text_btn, edit_buttons_btn, continue_editing_post)

    logging.info("Возвращаю клавиатуру для меню редактирования поста.")
    return keyboard
