from aiogram import Dispatcher
from aiogram.dispatcher.filters import CommandStart, Text

from tg_bot.handlers.users.start_menu import start_menu, return_start_menu
from tg_bot.handlers.users.edit_post_menu import edit_post_menu, return_edit_post_menu
from tg_bot.handlers.users.get_links import get_links
from tg_bot.handlers.users.set_text import wait_text, set_text
from tg_bot.handlers.users.set_buttons import wait_buttons, set_buttons
from tg_bot.handlers.users.start_posting_menu import start_edit_posts_menu, start_edit_posts
from tg_bot.states import EditPostsState


def register_user_menu(dp: Dispatcher):
    dp.register_message_handler(start_menu, CommandStart(), state="*")

    dp.register_message_handler(return_start_menu, Text("Назад"))
    dp.register_message_handler(return_start_menu, Text("Назад"), state=EditPostsState.WAIT_LINKS)

    dp.register_message_handler(get_links, Text("Отредактировать посты"), state="*")
    dp.register_callback_query_handler(get_links, Text("start_edit_posts_menu:add_offer"))

    dp.register_message_handler(return_edit_post_menu, Text("Назад"), state=EditPostsState.WAIT_BUTTONS)
    dp.register_message_handler(return_edit_post_menu, Text("Назад"), state=EditPostsState.WAIT_TEXT)

    dp.register_message_handler(edit_post_menu, state=EditPostsState.WAIT_LINKS)

    dp.register_callback_query_handler(wait_text, Text("edit_post_menu:set_text"))
    dp.register_message_handler(set_text, state=EditPostsState.WAIT_TEXT)

    dp.register_callback_query_handler(wait_buttons, Text("edit_post_menu:set_buttons"))
    dp.register_message_handler(set_buttons, state=EditPostsState.WAIT_BUTTONS)

    dp.register_callback_query_handler(start_edit_posts_menu, Text("edit_post_menu:continue"), state="*")

    dp.register_callback_query_handler(start_edit_posts, Text("start_edit_posts_menu:run"))