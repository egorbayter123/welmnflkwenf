import logging

from aiogram import types, Bot
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup

from tg_bot.keyboards.inline import get_edit_post_menu_keyboard
from tg_bot.states import EditPostsState


async def wait_text(query: types.CallbackQuery, state: FSMContext):  # Просим прислать текст, который будет установлен
    edit_message_id: int = query.message.message_id
    await state.update_data(edit_message_id=edit_message_id)

    await query.message.edit_text("Скинь сюда текст")
    await query.answer()

    await EditPostsState.WAIT_TEXT.set()

    logging.info("Ожидаю текст")


async def set_text(message: types.Message, state: FSMContext):  # Получаем текст и сохраняем его. Функция получает текст и сохраняет его в стейты, и возвращает в меню
    await state.reset_state(with_data=False)

    post_text: str = message.html_text
    user_id = message.from_user.id

    state_data = await state.get_data()
    edit_message_id: int = state_data.get("edit_message_id")
    bot: Bot = message.bot

    await state.update_data(post_text=post_text)

    edit_post_menu_keyboard: InlineKeyboardMarkup = await get_edit_post_menu_keyboard(state=state)

    await message.delete()
    await bot.edit_message_text(chat_id=user_id, message_id=edit_message_id, text="<b>⚖️ Постинг-меню</b>\n\nСохранил твой текст.", reply_markup=edit_post_menu_keyboard)

    logging.info(f"Текст установлен. Текст: {post_text}")