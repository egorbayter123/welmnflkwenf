import logging

from aiogram import types, Bot
from aiogram.dispatcher import FSMContext
from aiogram.types import InlineKeyboardMarkup

from tg_bot.keyboards.inline import get_edit_post_menu_keyboard
from tg_bot.models import Post


async def edit_post_menu(message: types.Message, state: FSMContext):
    state_data = await state.get_data()

    links: str = message.text
    links_list: list[str] = links.split("\n")
    posts_list: list[Post] = []

    for link in links_list:
        link = link.replace("https://", "").replace("t.me/", "").replace("c/", "")
        link = link.split("/")

        if len(link) != 2:
            logging.info(f"Отправлена неправильная ссылка. Ссылка: {link}\nСписок ссылок: {links_list}")

            await message.reply("<b>🔗 Получение ссылок</b>\n\nТы отправил неправильные ссылки! Попробуй еще раз.")
            return 0

        elif not link[1].isdigit():
            logging.info(f"Отправлена неправильная ссылка. Ссылка: {link}\nСписок ссылок: {links_list}")

            await message.reply("<b>🔗 Получение ссылок</b>\n\nТы отправил неправильные ссылки! Попробуй еще раз.")
            return 0

        entity: str = link[0]
        message_id: int = int(link[1])

        if entity.isdigit():
            entity = int("-100" + entity)
        else:
            entity = "@" + entity

        link_data = {
            "entity": entity,
            "message_id": message_id
        }

        posts_list.append(Post(**link_data))

    logging.info(f"Список полученных ссылок >> {posts_list}")  # Логируем список полученных ссылок

    await state.update_data(posts_list=posts_list)
    await state.reset_state(with_data=False)

    edit_post_menu_keyboard: InlineKeyboardMarkup = await get_edit_post_menu_keyboard(state=state)

    await message.answer("<b>⚙️ Постинг меню</b>\n\nПолучил твои ссылки. Теперь ты можешь установить текст и/или кнопки.", reply_markup=edit_post_menu_keyboard)


async def return_edit_post_menu(message: types.Message, state: FSMContext):
    await state.reset_state(with_data=False)

    user_id: int = message.from_user.id

    state_data: dict = await state.get_data()
    edit_message_id: int = state_data.get("edit_message_id")

    bot: Bot = message.bot
    edit_post_menu_keyboard: InlineKeyboardMarkup = await get_edit_post_menu_keyboard(state=state)

    await message.delete()
    await bot.edit_message_text(chat_id=user_id, message_id=edit_message_id, text="<b>⚖️ Постинг-меню</b>\n\nОтменил действие.", reply_markup=edit_post_menu_keyboard)