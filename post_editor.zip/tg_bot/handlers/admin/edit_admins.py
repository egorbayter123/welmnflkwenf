import logging

from aiogram import types
from aiogram.dispatcher import FSMContext

from tg_bot.config import Config
from tg_bot.keyboards.inline import return_admin_keyboard
from tg_bot.states import EditAdminState


async def add_admin_callback(query: types.CallbackQuery, state: FSMContext):
    await EditAdminState.WAIT_ADD_ID.set()
    await query.message.edit_text('<b>🎅🏽 Админы</b>\n\nСкинь ID аккаунта которому хочешь предоставить доступ к боту.',
                                  reply_markup=return_admin_keyboard)

    await state.update_data(message_id=query.message.message_id)


async def add_admin(message: types.Message, state: FSMContext):
    add_admin_id: int = int(message.text)
    config: Config = message.bot.get("config")
    state_data: dict = await state.get_data()
    edit_message_id: int = state_data["message_id"]

    config.bot.admins.append(add_admin_id)

    await message.delete()

    await message.bot.edit_message_text(
        text=f'<b>🎅🏽 Админы</b>\n\nАккаунту #ID{add_admin_id} успешно выдана админка.',
        chat_id=message.from_user.id, message_id=edit_message_id, reply_markup=return_admin_keyboard)

    await state.reset_state(with_data=False)

    logging.info(f"Доступ у {add_admin_id} успешно выдан.")


async def delete_admin_callback(query: types.CallbackQuery, state: FSMContext):
    await EditAdminState.WAIT_DELETE_ID.set()
    await query.message.edit_text(
        '<b>🎅🏽 Админы</b>\n\nСкинь ID аккаунта у которого хочешь забрать доступ к админке.',
        reply_markup=return_admin_keyboard)

    await state.update_data(edit_message_id=query.message.message_id)


async def delete_admin(message: types.Message, state: FSMContext):
    delete_admin_id = int(message.text.replace("#ID", ""))
    config: Config = message.bot.get("config")

    state_data: dict = await state.get_data()
    edit_message_id: int = state_data.get("edit_message_id")

    config.bot.admins.remove(delete_admin_id)

    await message.delete()
    await message.bot.edit_message_text(
        text=f'<b>🎅🏽 Админы</b>\n\nУ аккаунта #ID{delete_admin_id} успешно забран доступ к админке.',
        chat_id=message.from_user.id, message_id=edit_message_id)

    logging.info(f"Доступ у {delete_admin_id} успешно забран.")

    await state.reset_state(with_data=False)
