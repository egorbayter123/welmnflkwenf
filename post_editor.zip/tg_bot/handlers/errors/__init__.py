from aiogram import Dispatcher

from .error import errors_handler


def register_errors_handler(dp: Dispatcher):
    dp.register_errors_handler(errors_handler)